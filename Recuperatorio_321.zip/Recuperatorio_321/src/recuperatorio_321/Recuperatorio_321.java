package recuperatorio_321;

  import java.time.LocalDate;

public class Recuperatorio_321 {


    
    public static void main(String[] args) {
        GestorHallazgo gestor = new GestorHallazgo();

        try {
     
            Fosil fos1 = new Fosil("SitioA", "2020-05-26", 7, "Tiranosaurio", true);
            Herramienta her1 = new Herramienta("SitioB", "2020-05-23", 5, "Pedernal", "Cortar");
            Construccion con1 = new Construccion("SitioC", "2012-02-26", 4, "Templo", Epoca.COLONIAL);
            Construccion con2 = new Construccion("SitioD", "2023-05-06", 6, "Vivienda", Epoca.PRECOLOMBINA);

            gestor.registrarHallazgo(fos1);
            gestor.registrarHallazgo(her1);
            gestor.registrarHallazgo(con1);
            gestor.registrarHallazgo(con2);

            // ejemplo duplicado
            Fosil fosDuplicado = new Fosil("SitioA", "2020-05-26", 8, "Otro", false);
            gestor.registrarHallazgo(fosDuplicado); 

        } catch (HallazgoRepetidoException e) {
            System.out.println("ERROR: " + e.getMessage());
        }

        // Mostrar todo
        System.out.println(gestor.listarHallazgos());

        // Ejecutar análisis de laboratorio
        System.out.println(gestor.ejecutarAnalisisLaboratorio());

        // Realizar restauraciones
        System.out.println(gestor.realizarRestauraciones());

        // Filtrar por época
        System.out.println(gestor.mostrarFiltradoPorEpoca(Epoca.PRECOLOMBINA));

        // Mostrar por estado
        System.out.println(gestor.mostrarPorEstadoString(4, 6));
    }
}


