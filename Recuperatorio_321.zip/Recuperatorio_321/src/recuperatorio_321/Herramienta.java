package recuperatorio_321;

import java.time.LocalDate;

public class Herramienta extends Hallazgo implements Analizable {
    private final String material;
    private final String usoProbable;

    public Herramienta(String sitio, String fecha, int estadoConservacion, String material, String usoProbable) {
        super(sitio, fecha, estadoConservacion);
        this.material = material;
        this.usoProbable = usoProbable;
    }

    @Override
    public String descripcionEspecifica() {
        return String.format("Herramienta -> material:%s | usoProbable:%s", material, usoProbable);
    }

    @Override
    public String analizar() {
        return String.format("Analizando herramienta ID %d (material: %s): analisis de laboratorio completado. Uso probable: %s\n",
                getId(), material, usoProbable);
    }
}