package recuperatorio_321;


public enum Epoca {
    PRECOLOMBINA, 
    COLONIAL,
    MODERNA
}
