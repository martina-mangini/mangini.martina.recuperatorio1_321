package recuperatorio_321;


public interface Analizable {
    public String analizar();
}
