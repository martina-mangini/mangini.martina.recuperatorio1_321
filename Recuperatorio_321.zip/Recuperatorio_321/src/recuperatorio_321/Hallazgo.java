package recuperatorio_321;

import java.util.Objects;

public abstract class Hallazgo {
    private static int nextId = 50000;
    private final int id;
    private final String sitio;
    private final String fecha; 
    private int estadoConservacion; 

    public Hallazgo(String sitio, String fecha, int estadoConservacion) {
        this.id = nextId++;
        this.sitio = sitio;
        this.fecha = fecha;
        this.estadoConservacion = estadoConservacion;
        validarEstado();
    }

    private void validarEstado(){
        if (estadoConservacion < 1 || estadoConservacion > 10) {
            throw new IllegalArgumentException("Estado de conservacion debe ser entre 1 y 10");
        }
    }
    
    public int getId() {
        return id;
    }

    public String getSitio() {
        return sitio;
    }

    public String getFecha() {
        return fecha;
    }

    public int getEstadoConservacion() {
        return estadoConservacion;
    }

    public void setEstadoConservacion(int nuevoEstado) {
        if (nuevoEstado < 1) nuevoEstado = 1;
        if (nuevoEstado > 10) nuevoEstado = 10;
        this.estadoConservacion = nuevoEstado;
    }

    
    public abstract String descripcionEspecifica();

    @Override
    public String toString() {
        return String.format("ID:%d | Sitio:%s | Fecha:%s | Estado:%d | %s",
                id, sitio, fecha.toString(), estadoConservacion, descripcionEspecifica());
    }

    
    @Override
    public boolean equals(Object o) {
        if (this == o) 
            return true;
        if (!(o instanceof Hallazgo)) return false;
            Hallazgo h = (Hallazgo) o;
            return sitio.equals(h.sitio) && fecha.equals(h.fecha);
     }

    @Override
    public int hashCode() {
        return Objects.hash(sitio, fecha);
    }
}
