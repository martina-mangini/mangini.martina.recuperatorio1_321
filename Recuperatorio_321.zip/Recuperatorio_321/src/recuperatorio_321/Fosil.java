package recuperatorio_321;

public class Fosil extends Hallazgo implements Analizable {
    private final String especie;
    private final boolean esqueletoCompleto;

    public Fosil(String sitio, String fecha, int estadoConservacion, String especie, boolean esqueletoCompleto) {
        super(sitio, fecha, estadoConservacion);
        this.especie = especie;
        this.esqueletoCompleto = esqueletoCompleto;
    }

    @Override
    public String descripcionEspecifica() {
        return String.format("Fosil -> especie:%s | esqueletoCompleto:%s",
                especie, esqueletoCompleto ? "SI" : "NO");
    }

    @Override
    public String analizar() {
        return String.format("Analizando fosil ID %d (%s): analisis realizado. Esqueleto completo: %s\n",
                getId(), especie, esqueletoCompleto ? "SI" : "NO");
    }
}
