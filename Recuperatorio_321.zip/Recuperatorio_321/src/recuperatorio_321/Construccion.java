package recuperatorio_321;

public class Construccion extends Hallazgo implements Restaurable {
    private final String tipoEdificacion;
    private final Epoca epoca;

    public Construccion(String sitio, String fecha, int estadoConservacion, String tipoEdificacion, Epoca epoca) {
        super(sitio, fecha, estadoConservacion);
        this.tipoEdificacion = tipoEdificacion;
        this.epoca = epoca;
    }

    public Epoca getEpoca() {
        return epoca;
    }

    @Override
    public String descripcionEspecifica() {
        return String.format("Construccion -> tipo:%s | epoca:%s", tipoEdificacion, epoca);
    }

    @Override
    public String restaurar() {
        int anterior = getEstadoConservacion();
        setEstadoConservacion(anterior + 1);
        return String.format("Restaurando construccion ID %d (tipo: %s): estado %d -> %d\n",
                getId(), tipoEdificacion, anterior, getEstadoConservacion());
    }
}
