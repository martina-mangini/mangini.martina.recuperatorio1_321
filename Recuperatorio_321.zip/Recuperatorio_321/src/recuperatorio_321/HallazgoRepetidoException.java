package recuperatorio_321;

public class HallazgoRepetidoException extends Exception {
    public HallazgoRepetidoException(String mensaje) {
        super(mensaje);
    }
}

