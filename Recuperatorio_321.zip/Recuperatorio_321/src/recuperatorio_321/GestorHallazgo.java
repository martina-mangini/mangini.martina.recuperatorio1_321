package recuperatorio_321;

import java.util.ArrayList;
import java.util.List;

public class GestorHallazgo {
    private final ArrayList<Hallazgo> hallazgos;

    public GestorHallazgo() {
        this.hallazgos = new ArrayList<>();
    }

    public void registrarHallazgo(Hallazgo h) throws HallazgoRepetidoException {
        if (hallazgos.contains(h)) {
            throw new HallazgoRepetidoException("Ya existe un hallazgo en el mismo sitio con la misma fecha: ");
        }
        hallazgos.add(h);
    }


    public String listarHallazgos() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== HALLAZGOS REGISTRADOS ===\n");
        for (Hallazgo h : hallazgos) {
            sb.append(h.toString()).append("\n");
        }
        return sb.toString();
    }


    public String ejecutarAnalisisLaboratorio() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== ANALISIS DE LABORATORIO ===\n");
        for (Hallazgo h : hallazgos) {
            if (h instanceof Analizable) {
                sb.append(((Analizable) h).analizar());
            } else {
                sb.append(String.format("ID %d no es analizable (tipo: %s)\n", h.getId(), h.getClass().getSimpleName()));
            }
        }
        return sb.toString();
    }


    public String realizarRestauraciones() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== RESTAURACIONES ===\n");
        for (Hallazgo h : hallazgos) {
            if (h instanceof Restaurable) {
                sb.append(((Restaurable) h).restaurar());
            } else {
                sb.append(String.format("ID %d no es restaurable (tipo: %s)\n", h.getId(), h.getClass().getSimpleName()));
            }
        }
        return sb.toString();
    }

   
    public List<Hallazgo> filtrarPorEpoca(Epoca epoca) {
        List<Hallazgo> resultado = new ArrayList<>();
        for (Hallazgo h : hallazgos) {
            if (h instanceof Construccion) {
                Construccion c = (Construccion) h;
                if (c.getEpoca() == epoca) {
                    resultado.add(c);
                }
            }
        }
        return resultado;
    }

    public String mostrarFiltradoPorEpoca(Epoca epoca) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== HALLAZGOS - EPOCA: ").append(epoca).append(" ===\n");
        for (Hallazgo h : filtrarPorEpoca(epoca)) {
            sb.append(h.toString()).append("\n");
        }
        return sb.toString();
    }

   
    public List<Hallazgo> mostrarPorEstado(int desde, int hasta) {
        List<Hallazgo> resultado = new ArrayList<>();
        for (Hallazgo h : hallazgos) {
            int e = h.getEstadoConservacion();
            if (e >= desde && e <= hasta) {
                resultado.add(h);
            }
        }
        return resultado;
    }

    
    public String mostrarPorEstadoString(int desde, int hasta) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("=== HALLAZGOS con estado entre %d y %d ===\n", desde, hasta));
        for (Hallazgo h : mostrarPorEstado(desde, hasta)) {
            sb.append(h.toString()).append("\n");
        }
        return sb.toString();
    }
}
