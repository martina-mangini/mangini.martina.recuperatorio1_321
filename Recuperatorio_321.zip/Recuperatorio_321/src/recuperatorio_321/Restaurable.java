package recuperatorio_321;


public interface Restaurable {
     public String restaurar();
}
